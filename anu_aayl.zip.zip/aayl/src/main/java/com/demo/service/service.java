package com.demo.service;

import java.sql.CallableStatement;

import java.sql.Connection;
import java.sql.SQLException;

import org.springframework.stereotype.Service;

import com.demo.model.login;
import com.demo.model.user;
import com.demo.utility.DBUtil;

@Service
public class service {
                private static Connection connection=null;
                public service() {
                   try {
					connection = DBUtil.getConnection();
					/*if(connection ==null){
						System.out.println("CONNECTION not  DONE");
						
					}else{
						System.out.println("CONNECTION  DONE");
						
					}*/
					
					
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
                }
                
                 public String register(login log) {
                	 String fname=" ";
                                  try {
                                   CallableStatement stmt = connection.prepareCall("call loginprocess(?, ?,?,?)");
                                   stmt.setInt(1, 5678);
                             
                                   stmt.setString(3, log.getuserName());   
                                   stmt.setString(4, log.getuserPass());
                                   stmt.registerOutParameter(2, java.sql.Types.CHAR,fname);
                                  stmt.execute();
                                  fname=stmt.getString(2);
                                  log.setFirstname(fname);
                                  } catch (SQLException e) {
                                   e.printStackTrace();
                                  }
                                  System.out.println("WELCOME "+fname);
                                  return fname;
                                  
                                }
}





