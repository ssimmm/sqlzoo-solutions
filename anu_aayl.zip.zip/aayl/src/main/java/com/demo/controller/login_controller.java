package com.demo.controller;

import java.text.ParseException;
import java.util.List;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.login;
import com.demo.model.user;
import com.demo.service.service;
@RestController
public class login_controller {
       service mapservice=new service();
       
        
        @RequestMapping(value="/validation/{username}/{password}",method = RequestMethod.POST)
         public String validation(@PathVariable String username,@PathVariable String password) throws ParseException { 
         login log = new login();
         log.setuserName(username);
         log.setuserPass(password);
         String valid=mapservice.register(log);
         System.out.println(valid);
         return valid;
       }
}
