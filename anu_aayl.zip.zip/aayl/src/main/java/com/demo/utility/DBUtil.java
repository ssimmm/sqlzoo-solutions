package com.demo.utility;

import java.sql.Connection;

	import java.sql.DriverManager;

	import java.sql.SQLException;

	public class DBUtil {

	        private static Connection connection = null;

	    public static Connection getConnection() throws ClassNotFoundException {

	        if (connection != null)

	            return connection;

	        else {

	            try {
	            	Class.forName("oracle.jdbc.driver.OracleDriver");  
	             

	                connection = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02", "shobana", "shobana");

	            } 

	            catch (SQLException e) {

	                e.printStackTrace();

	            }

	            return connection;

	        }

	    }

	}




