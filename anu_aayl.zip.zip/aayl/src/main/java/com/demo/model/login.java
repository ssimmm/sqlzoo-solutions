package com.demo.model;

import javax.servlet.http.HttpSession;

public class login {
	private int userid;
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	private String userName;
    private String userPass;
    private String firstname;
    
    
    public login(String userName, String userPass) {
		super();
		this.userName = userName;
		this.userPass = userPass;
	}
	public login() {
		super();
	}
	public String getuserName() {
    return userName;
    }
    public void setuserName(String userName) {
    this.userName = userName;
    }
    public String getuserPass() {
    return userPass;
    }
    public void setuserPass(String userPass) {
    this.userPass = userPass;
    }

}
